#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""collect_changes.py — 确定性收集 git 仓库变更信息，输出结构化摘要。

用途：为提交信息生成提供可靠输入，避免逐条手敲 git 命令与遗漏文件。
仅使用标准库；兼容 Python 3.7+；跨平台（Windows/Linux/macOS）。

用法：
  python collect_changes.py                     # 分析当前目录（工作区+暂存区全部变更）
  python collect_changes.py --repo <path>       # 指定仓库路径
  python collect_changes.py --max-diff 100      # 每文件 diff 最多输出 100 行（默认 200）
  python collect_changes.py --no-diff           # 只输出 status/diffstat，不输出 diff 正文

输出结构（stdout，UTF-8）：
  [repo]      仓库根、当前分支、与上游 ahead/behind
  [status]    按类别分组的文件清单（新增/修改/删除/重命名，区分工作区与暂存区）
  [diffstat]  每文件增删行数
  [diff]      每文件 diff 正文（截断）
  [recent]    最近 5 条提交信息（供风格对齐参考）

退出码：0 成功；1 非 git 仓库或 git 不可用；2 无变更。
"""
import argparse
import io
import os
import subprocess
import sys

# Windows 控制台默认 GBK，强制 UTF-8 输出避免中文乱码
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
else:
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")


def run_git(repo, args, check=True):
    result = subprocess.run(
        ["git", "-C", repo] + args,
        capture_output=True,
    )
    if check and result.returncode != 0:
        sys.stderr.write(result.stderr.decode("utf-8", errors="replace"))
        sys.exit(1)
    return result.stdout.decode("utf-8", errors="replace")


def main():
    ap = argparse.ArgumentParser(description="Collect git changes for commit message drafting")
    ap.add_argument("--repo", default=".", help="仓库路径（默认当前目录）")
    ap.add_argument("--max-diff", type=int, default=200, help="每文件 diff 最大行数（默认 200）")
    ap.add_argument("--no-diff", action="store_true", help="不输出 diff 正文")
    args = ap.parse_args()

    repo = os.path.abspath(args.repo)
    probe = subprocess.run(["git", "-C", repo, "rev-parse", "--show-toplevel"], capture_output=True)
    if probe.returncode != 0:
        sys.stderr.write("ERROR: %s 不是 git 仓库（或 git 不可用）\n" % repo)
        sys.exit(1)
    root = probe.stdout.decode("utf-8", errors="replace").strip()

    # [repo] 基本信息
    branch = run_git(root, ["rev-parse", "--abbrev-ref", "HEAD"]).strip()
    upstream = run_git(root, ["rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}"],
                       check=False).strip()
    ahead_behind = ""
    if upstream:
        ab = run_git(root, ["rev-list", "--left-right", "--count", "%s...HEAD" % upstream],
                     check=False).strip()
        if ab:
            behind, ahead = ab.split("\t")
            ahead_behind = "（相对上游 %s：ahead %s / behind %s）" % (upstream, ahead, behind)
    else:
        upstream = "（无上游分支，push 需 -u 指定）"
    print("[repo]")
    print("root: %s" % root)
    print("branch: %s" % branch)
    print("upstream: %s %s" % (upstream, ahead_behind))

    # [status] porcelain v1：XY filename（core.quotepath=false 保持非 ASCII 文件名可读）
    status_out = run_git(root, ["-c", "core.quotepath=false", "status", "--porcelain=v1", "-uall"])
    if not status_out.strip():
        print("\n[status]\n（工作区与暂存区均无变更）")
        sys.exit(2)
    entries = []  # (X, Y, path)
    for line in status_out.splitlines():
        if len(line) >= 4:
            entries.append((line[0], line[1], line[3:].strip()))

    def classify(x, y):
        if x == "A" or y == "A":
            return "新增"
        if x == "D" or y == "D":
            return "删除"
        if x == "R" or y == "R":
            return "重命名"
        if x == "C" or y == "C":
            return "复制"
        if x in ("M", "T") or y in ("M", "T"):
            return "修改"
        if x == "?" or y == "?":
            return "未跟踪"
        if x == "!":
            return "已忽略"
        return "其他(%s%s)" % (x, y)

    groups = {}
    for x, y, path in entries:
        groups.setdefault(classify(x, y), []).append((x, y, path))

    print("\n[status]")
    for cat in ("新增", "修改", "删除", "重命名", "复制", "未跟踪", "其他"):
        if cat not in groups:
            continue
        print("%s (%d):" % (cat, len(groups[cat])))
        for x, y, path in groups[cat]:
            area = "staged" if x not in (" ", "?") else "unstaged"
            print("  [%s] %s" % (area, path))

    # [diffstat] numstat：add deletions path（二进制为 -）
    print("\n[diffstat]")
    numstat = run_git(root, ["-c", "core.quotepath=false", "diff", "HEAD", "--numstat"], check=False)
    if not numstat.strip():
        numstat = run_git(root, ["-c", "core.quotepath=false", "diff", "--numstat", "--cached"], check=False)
    print(numstat.strip() or "（无行级统计）")

    # [diff] 正文
    if not args.no_diff:
        print("\n[diff]")
        for x, y, path in entries:
            if classify(x, y) in ("删除",):
                diff_args = ["diff", "HEAD", "--", path]
            else:
                diff_args = ["diff", "HEAD", "--", path]
            out = run_git(root, ["-c", "core.quotepath=false"] + diff_args, check=False)
            if not out.strip() and (x == "A" or y == "A" or x == "?"):
                # 未跟踪文件：展示其内容前若干行
                fp = os.path.join(root, path.replace("/", os.sep))
                if os.path.isfile(fp):
                    try:
                        with open(fp, "rb") as f:
                            data = f.read(8192)
                        out = "(新文件，前 8KB 内容)\n" + data.decode("utf-8", errors="replace")
                    except OSError as e:
                        out = "(无法读取: %s)" % e
            lines = out.splitlines()
            truncated = len(lines) > args.max_diff
            print("----- %s -----" % path)
            print("\n".join(lines[: args.max_diff]))
            if truncated:
                print("...（截断，共 %d 行）" % len(lines))

    # [recent] 最近提交风格参考
    print("\n[recent]")
    log = run_git(root, ["log", "--oneline", "-5"], check=False).strip()
    print(log or "（无历史提交）")


if __name__ == "__main__":
    main()
