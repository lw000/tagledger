---
name: git-commit-assistant
description: 自动分析项目 git 变更并生成提交信息的技能。分析工作区与暂存区的全部修改（新增/修改/删除/重命名），产出变更总结与符合 Conventional Commits 规范的提交信息，经用户人工确认后执行 git commit 与 push。当用户提出"提交代码""commit""提交并推送""生成提交信息""push"等意图，或要求对当前改动做变更总结时使用。
---

# Git Commit Assistant

## Overview

本技能将"分析变更 → 起草提交信息 → 人工确认 → commit → push"固化为标准流程：
1. 用 `scripts/collect_changes.py` 确定性收集变更（status 分类、diffstat、diff、最近提交风格）
2. 生成变更总结与规范提交信息，呈现给用户确认
3. 确认后执行 `git commit`；推送前再次确认，然后 `git push`

**安全边界（硬性）**：未经用户明确确认，不得执行 commit；未经用户明确确认，不得执行 push；禁止 `--force`/`-f` 推送、禁止 `git reset --hard`/`clean`/`checkout -- .` 等破坏性操作；确认必须来自用户对本方案的真实选择，AI 不得自行视为已确认。

## Workflow

### Step 1 — 收集变更

运行收集脚本（跨平台，仅标准库，兼容 Python 3.7+）：

```bash
python <skill-dir>/scripts/collect_changes.py --repo <项目路径>
```

- 默认输出 `[repo]`（分支/上游/ahead-behind）、`[status]`（新增/修改/删除/重命名/未跟踪分组）、`[diffstat]`、`[diff]`（每文件，默认截断 200 行）、`[recent]`（最近 5 条提交，供风格对齐）
- 退出码 1 = 非 git 仓库（终止并告知用户）；2 = 无变更（终止并告知）
- 大仓库可加 `--no-diff` 先看全貌，再对关键文件单独 `git diff -- <file>`
- 若项目存在 `changelog/` 或变更日志，读取最新条目，与 git status 交叉核对——差异项要在总结中说明（漏记或未日志化的情况）

### Step 2 — 分析与起草

按 `references/commit-style.md` 生成两部分内容：

1. **变更总结**：按模块/主题分组（不逐文件流水账），覆盖新增/修改/删除各类；标注影响面（接口/构建/行为）与风险点；区分"已暂存/未暂存/未跟踪"
2. **提交信息草案**：`type(scope): subject` + body；跨模块大改动 scope 用 `*`；破坏性变更加 `!` 与 `BREAKING CHANGE:` footer

**拆分判定**：变更包含多个无关主题时，提出按文件分组拆分为多个提交的方案（每组给出独立提交信息），让用户选择"单提交"或"拆分"。

**风格对齐**：`[recent]` 中的历史提交若与规范冲突且用户偏好历史风格，以用户选择为准。

### Step 3 — 人工确认（commit 前，必经）

向用户呈现：变更总结 + 提交信息草案 + 拟执行的命令清单（将 `git add` 哪些文件、commit、是否 push）。用选择题让用户确认/修改/拆分/放弃。用户未回应前不得执行任何 git 写操作。

### Step 4 — 提交

确认后执行：

```bash
git add <确认范围内的文件>        # 逐文件列出，禁止 git add -A / git add . 一把梭
git commit -m "<subject>" -m "<body>"
```

- 多行 body 用多个 `-m`；含引号/特殊字符时改用 `git commit -F <临时文件>`（临时文件用 UTF-8 编码，提交后删除）
- 提交后运行 `git log -1 --stat` 核对：提交包含的文件与确认范围一致
- 失败（如 pre-commit hook 拒绝）时如实报告，不得用 `--no-verify` 绕过（除非用户明确要求）

### Step 5 — 推送（push 前，二次确认）

push 是对外可见动作，必须独立于 commit 单独确认：

1. 检查上游：`git rev-parse --abbrev-ref --symbolic-full-name @{u}`
   - 无上游：说明将使用 `git push -u origin <branch>`（首次推送新分支），并确认远程名正确
   - ahead 0：无需推送，告知即可
   - behind > 0：先向用户确认处理方式（`git pull --rebase` 或 merge），不得直接强推
2. 用户确认后执行 `git push`（或 `-u origin <branch>`）
3. 推送后输出远端结果；失败（权限/网络/保护分支）时原样呈现错误，不得改用 force push

### 异常与边界

- **未初始化仓库**：告知用户 `git init` 与远程配置步骤，经确认后代为执行
- **敏感文件**（.env、密钥、凭证、超大二进制）：出现在变更中时单独警示，默认排除并说明
- **合并冲突**：停止并呈现冲突文件，不自动解决
- **用户中途修改代码**：回到 Step 1 重新收集

## Resources

- `scripts/collect_changes.py` — 变更收集脚本（status 分组/diffstat/diff/历史风格，UTF-8 输出）
- `references/commit-style.md` — 提交信息规范（Conventional Commits 中文基线；项目自有规范优先）
