# Commit Message 规范（Conventional Commits · 中文描述）

生成提交信息时遵循本规范；若项目根目录存在 `CODEBUDDY.md`、`CONTRIBUTING.md` 或 `.gitmessage` 等自有规范，**以项目规范为准**（更具体者胜），本文件作为缺省基线。

## 1. 格式

```
<type>(<scope>): <subject>

[body]

[footer]
```

- **type** 必选，英文小写，见第 2 节
- **scope** 可选，英文小写 kebab-case，表示变更范围（模块/目录/子系统），如 `common`、`http-server`、`docs`
- **subject** 必选，中文一行，不超过 50 字，祈使/陈述式，结尾不加句号；写清"做了什么"与"为什么"中最关键的一点
- **body** 可选：补充动机、方案要点、影响面；每行不超过 72 字；多个要点用 `-` 列表
- **footer** 可选：`Refs #123`、`BREAKING CHANGE: <说明>`、`Co-authored-by: ...`

## 2. type 取值

| type | 使用场景 |
| --- | --- |
| feat | 新功能 |
| fix | 缺陷修复 |
| refactor | 重构（不改变行为） |
| perf | 性能优化 |
| test | 测试新增/修改（不含构建配置） |
| docs | 纯文档变更 |
| build | 构建系统/依赖变更（CMake、第三方库引入/升级） |
| ci | CI/脚本配置变更 |
| chore | 其他杂项（.gitignore、辅助脚本等） |
| revert | 回滚（格式：`revert: <被回滚提交的 subject>`） |

判定顺序：先问"是否改变运行时行为"（改变则用 feat/fix/perf，不改则用 refactor/docs/build/chore 等），再问"动机是新能力还是修复"。

## 3. scope 取值

- 单模块变更：模块/目录名（`csv-store`、`logger`、`changelog`）
- 跨模块：取主导模块，或用 `*` 表示全局性变更（如更名、工具链升级）
- 文档类：`docs`；构建类：`build`；测试类：`tests`

## 4. subject 写法要点

- 面向"变更目的与范围"，不面向 diff 细节：`feat(csv-store): 支持批量写入与原子拒绝` 而非 `修改了 csv_store.cpp`
- 缺陷修复写症状或根因：`fix(web): 修复表单重置后文件标签节点被销毁导致点表不刷新`
- 行为等价重构点明等价性：`refactor(util): 文件操作层迁移至 std::filesystem（公开 API 不变）`
- 破坏性变更必须在 body/footer 显式声明 `BREAKING CHANGE:`

## 5. 场景示例

新增/修改/删除混合（一次功能交付）：

```
feat(logger): 新增 spdlog 日志系统并全量替换旧日志输出

- 引入 spdlog 1.17.0（编译库形态），封装 common/logger 统一入口
- 配置落 app.toml [log] 段（等级/异步队列/轮转保留策略）
- 删除 util 中旧 log_line 接口，22 处调用点全量替换
- 新增 test_logger.cpp 6 用例；轮转保留策略含当前文件共 100 个
```

纯删除：

```
chore: 移除废弃的 docs/00 外置规范文档

内容已全部并入 CODEBUDDY.md，消除双源维护。
```

重命名/迁移：

```
refactor(*)!: 项目更名 collector → tagledger

- 全量重命名目录/target/产品字符串/文档引用
- BREAKING CHANGE: 可执行文件与 CMake target 名称变更
```

## 6. 禁止事项

- 禁止 `update`、`修改代码`、`fix bug` 等无信息量 subject
- 禁止在一个提交中混合无关变更（发现时提示用户拆分提交，按文件分组分别 commit）
- 禁止 subject 中出现敏感信息（密钥、内网地址、个人隐私）
- 不得伪造 `Co-authored-by`；除非用户要求，不添加 AI 署名 
